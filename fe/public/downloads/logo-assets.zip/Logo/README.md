# Logo Assets

This folder contains all logo assets for the Gunnies project.

## Structure
- `PNG/` - PNG format logos
- `SVG/` - SVG format logos
- `Brand Guidelines/` - Brand guidelines and usage instructions

## Usage
These assets are available for partners and should be used according to the brand guidelines. 