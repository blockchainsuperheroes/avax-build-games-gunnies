# SVG Logo Assets

This folder contains SVG format logo files.

## Files
- `gunnies-logo.svg` - Main logo in SVG format
- `gunnies-logo-white.svg` - White version of the logo
- `gunnies-logo-black.svg` - Black version of the logo
- `gunnies-icon.svg` - Icon version of the logo

## Benefits
- Scalable to any size without quality loss
- Smaller file sizes
- Perfect for web and print use 