# PNG Logo Assets

This folder contains PNG format logo files.

## Files
- `gunnies-logo.png` - Main logo in PNG format
- `gunnies-logo-white.png` - White version of the logo
- `gunnies-logo-black.png` - Black version of the logo
- `gunnies-icon.png` - Icon version of the logo

## Sizes
- Standard: 512x512px
- High resolution: 1024x1024px
- Web optimized: 256x256px 